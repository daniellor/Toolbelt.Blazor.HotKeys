// THIS FILE IS AUTO GENERATED IN THE MSBUILD SCRIPT
import { Toolbelt } from './script.min.js?v=11.0.0-preview.1';
window['Toolbelt'] = Toolbelt;
